* New Essential Menu By Anonik*

=========================================
REQUIREMENTS

LEMONUI SCHVDN3
SCRIPTHOOKDOTNET V3
SCRIPTHOOKV
LEGAL COPY OF GTA V

========================================

INSTALLATION

Put All Files inside your GTA 5 Folder

=======================================

How To Open the Menu ?

F6 To Open (edit the esconfig.ini to change the default key)
Arrow Up And Down to scroll


======================================
DISCLAIMER
This version of Essential Menu is very very Embrional if you want to improve the code you can help me via GitHub
here the link: https://github.com/anonik9900/EssentialMenu-LEMON/